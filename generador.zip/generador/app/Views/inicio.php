      <div class="container-fluid h-100 d-inline-block">
        <div class="card">
          <br><br>
          <div class="col-auto mx-auto">
                <h1>Generador de Contraseñas</h1>
              </div>
          <div class="card-body g-3 mx-auto">
            <form class="row g-3 mx-auto" >
              <div class="col-auto mx-auto">
                <label for="nombre" class="visually-hidden">Nombre</label>
                <input type="text" class="form-control" placeholder="Ingresa el nombre del Funcionario" name="nombre" id="nombre">
                <strong><p class="form-control" id="resultado"></p></strong>
              </div>
              <div class="col-auto mx-auto">
                <button type="button" id="generar" class="btn btn-primary mb-3">Generar</button>
              </div>
              <br>
            </form>
          </div>
        </div>
        <div class="content-backdrop fade"></div>
      </div>
    </div>
  </div>
  <div class="layout-overlay layout-menu-toggle"></div>
</div>
</body>
  <!-- Librerias de movimiento -->
  <script src="<?php echo base_url('public/assets/vendor/libs/jquery/jquery.js');?>"></script>
  <script src="<?php echo base_url('public/assets/vendor/libs/popper/popper.js');?>"></script>
  <script src="<?php echo base_url('public/assets/vendor/js/bootstrap.js');?>"></script>
  <script src="<?php echo base_url('public/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js');?>"></script>
  <script src="<?php echo base_url('public/assets/vendor/js/menu.js');?>"></script>
  <script src="<?php echo base_url('public/assets/js/main.js');?>"></script>
  <script src="<?php echo base_url('public/assets/js/moment.min.js');?>"></script>
  <script src="<?php echo base_url('public/assets/js/ui-toasts.js');?>"></script>
  <script src="<?php echo base_url('public/assets/js/ui-popover.js');?>"></script>
  <script src="<?php echo base_url('public/assets/js/inicio.js').'?v='.rand();?>"></script>
  <script async defer src="<?php echo base_url('public/assets/js/buttons.js');?>"></script>
</html>