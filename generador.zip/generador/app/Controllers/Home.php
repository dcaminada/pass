<?php

namespace App\Controllers;
use App\Libraries\Autoload;
use App\Libraries\FPDF;
use App\Libraries\PDF_Code128;

class Home extends BaseController
{
    public function index()
    {
        echo view('layouts/header');
        echo view('inicio');
    }

    public function codigo()
    {
        $tribunal = $this->request->getPostGet('tribunal');
        $codigo = $this->request->getPostGet('codigo');
        $nombre = $this->request->getPostGet('nombre');

        $pdf=new PDF_Code128('l','mm',array(90,45));

        for ($i=0; $i < count($tribunal); $i++) { 

            $pdf->AddPage();
            $pdf->SetMargins(5, 11 , 0);
            $pdf->SetAutoPageBreak(false);
            $pdf->SetFont('Arial','B',14);
            $pdf->cell(53,-7,'PODER JUDICIAL',0,0,'L'); 
            $pdf->Ln(0);
            $pdf->SetFont('Arial','',12);
            $bien1 = ''.$tribunal[$i].'';
            $bienMay1 = strtoupper($bien1);
            $bienRecort1 = substr($bienMay1, 0, 26);
            $pdf->cell(70,1,''.$bienRecort1.'',0,0,'R'); 
            $code=''.$codigo[$i].'';
            $pdf->Code128(12,14,$code,62,15);
            $pdf->Ln(19);
            $pdf->SetFont('Arial','B',15);
            $pdf->Write(5,'              '.$code.'');
            $pdf->SetFont('Arial','',12);
            $pdf->Ln(8);
            $bien = ''.$nombre[$i].'';
            $bienMay = strtoupper($bien);
            $bienRecort = substr($bienMay, 0, 26);
            $pdf->cell(77,0,''.$bienRecort.'',0,0,'C'); 
            $pdf->Ln(0);

        }

        if($pdf->Output(date("YmdHis").'.pdf','D')){
            return redirect()->to(base_url('/'));
        }

    }

}
