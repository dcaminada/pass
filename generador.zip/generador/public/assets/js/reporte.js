$(document).ready(function() {
  let Month = [0,31,28,31,30,31,30,31,31,30,31,30,31];
  var Day = new Date().getUTCDay();
  var FirstMonth = new Date().getMonth();
  var FirstYear = new Date().getFullYear();
  var FirstDate = new Date().toUTCString();
  var FirstDay = FirstDate.split(" ");

  var Mes = [];
  $("#mes option[value="+ (FirstMonth+1) +"]").attr("selected",true);
  $("#anio option[value="+ (FirstYear) +"]").attr("selected",true);
  for (var i = 1; i <= Month[$("#mes").val()]; i++) {
    Mes.push(parseInt(i));
  }
  var fechaReporIni = new Date($("#mes").val()+"-1-"+$("#anio").val()).toISOString().split('T')[0];
  var fechaReporFin = new Date($("#mes").val()+"-"+Month[$("#mes").val()]+"-"+$("#anio").val()).toISOString().split('T')[0];
  $("#fecha1").val(fechaReporIni);
  $("#fecha2").val(fechaReporFin);
  $("#nombre").val($("#buscadorPersonas").val());

  var URLactual = window.location.href;
  var URL_ = URLactual.split("/");
  $("#"+URL_[4]).addClass("active");

  ajaxUser(Mes, fechaReporIni, fechaReporFin);

  $("#mes").on( 'change', function() {
    var Mes = [];
    for (var i = 1; i <= Month[$("#mes").val()]; i++) {
      Mes.push(parseInt(i));
    }
    var fechaReporIni = new Date($("#mes").val()+"-1-"+$("#anio").val()).toISOString().split('T')[0];
    var fechaReporFin = new Date($("#mes").val()+"-"+Month[$("#mes").val()]+"-"+$("#anio").val()).toISOString().split('T')[0];
    $("#fecha1").val(fechaReporIni);
    $("#fecha2").val(fechaReporFin);
    $("#nombre").val($("#buscadorPersonas").val());
    if($("#buscadorPersonas").val() == ""){
      ajaxUser(Mes, fechaReporIni, fechaReporFin);
    }else{
      buscador($("#buscadorPersonas").val(), Mes, fechaReporIni, fechaReporFin);
    }
  });

  $("#anio").on( 'change', function() {
    var Mes = [];
    for (var i = 1; i <= Month[$("#mes").val()]; i++) {
      Mes.push(parseInt(i));
    }
    var fechaReporIni = new Date($("#mes").val()+"-1-"+$("#anio").val()).toISOString().split('T')[0];
    var fechaReporFin = new Date($("#mes").val()+"-"+Month[$("#mes").val()]+"-"+$("#anio").val()).toISOString().split('T')[0];
    $("#fecha1").val(fechaReporIni);
    $("#fecha2").val(fechaReporFin);
    $("#nombre").val($("#buscadorPersonas").val());
    if($("#buscadorPersonas").val() == ""){
      ajaxUser(Mes, fechaReporIni, fechaReporFin);
    }else{
      buscador($("#buscadorPersonas").val(), Mes, fechaReporIni, fechaReporFin);
    }
  });

  $("#tipoReport").on( 'change', function(){
    const selectFile = document.querySelector("#formButton");
    if($("#tipoReport").val()==1){
      selectFile.setAttribute("action", "/asistencia/reporte/reportPDF");
    }else if($("#tipoReport").val()==2){
      selectFile.setAttribute("action", "/asistencia/reporte/reportExcel");
    }
   
  });

  $("#permiso").on( 'change', function(){
    const checkboxDate = document.querySelector("#masDia");
    const inputDate = document.querySelector("#input-fin");
    if($("#permiso").val()==0){
      $("#mysubmit").addClass("disabled");
      ocultar("detalle");
      ocultar("divHidden");
      ocultar("divTime");
      checkboxDate.setAttribute("disabled", "");
      inputDate.setAttribute("disabled", "");
      $("#ldia").text("Dia");
      $("#lfin").text(" - ");
    }else if($("#permiso").val()==8){
      ocultar("detalle");
      ocultar("divHidden");
      ocultar("divTime");
      checkboxDate.removeAttribute("disabled");
      $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==9){
      ocultar("detalle");
      ocultar("divHidden");
      ocultar("divTime");
      checkboxDate.removeAttribute("disabled");
      $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==6){
      mostrar("detalle");
      mostrar("divHidden");
      ocultar("divTime");
      checkboxDate.removeAttribute("disabled");
      inputDate.setAttribute("disabled", "");
      $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==7){
      ocultar("detalle");
      mostrar("divHidden");
      ocultar("divTime");
      checkboxDate.removeAttribute("disabled");
      $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==3){
      ocultar("detalle");
      ocultar("divHidden");
      ocultar("divTime");
      checkboxDate.removeAttribute("disabled");
      $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==2){
      ocultar("detalle");
      ocultar("divHidden");
      mostrar("divTime");
      checkboxDate.removeAttribute("disabled");
      $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==10){
      ocultar("detalle");
      ocultar("divHidden");
      ocultar("divTime");
      $("#mysubmit").removeClass("disabled");
    }
  });
  $("#masDia").on( 'change', function(){
    if(this.checked){
      const inputDate = document.querySelector("#input-fin");
      inputDate.removeAttribute("disabled");
      $("#ldia").text("Inicio");
      $("#lfin").text("Fin");
    }else{
      const inputDate = document.querySelector("#input-fin");
      inputDate.setAttribute("disabled", "");
      $("#ldia").text("Dia");
      $("#lfin").text(" - ");
    }
  });
  $("#manana").on( 'change', function(){
    if(this.checked) {
      const checkboxTarde = document.querySelector("#tarde");
      checkboxTarde.setAttribute("disabled", "");
    }else{
      const checkboxTarde = document.querySelector("#tarde");
      checkboxTarde.removeAttribute("disabled");
    }
  });
  $("#tarde").on( 'change', function(){
    if(this.checked){
      const checkboxManana = document.querySelector("#manana");
      checkboxManana.setAttribute("disabled", "");
    }else{
      const checkboxManana = document.querySelector("#manana");
      checkboxManana.removeAttribute("disabled");
    }
  });
  $("#input-fin").on( 'change', function(){
    if($("#permiso").val()==9){
      var results = diasEntreFechas(moment($("#input-dia").val()), moment($("#input-fin").val()), 0);
      $("#fecha").val(results);
    }else{
      var results = diasEntreFechas(moment($("#input-dia").val()), moment($("#input-fin").val()), 1);
      $("#fecha").val(results);
    }
  });
  $("#input-dia").on( 'change', function(){
    if($("#permiso").val()==9){
      var results = diasEntreFechas(moment($("#input-dia").val()), moment($("#input-dia").val()), 0);
      $("#fecha").val(results);
      $("#input-fin").val($("#input-dia").val());
      $("#input-fin").attr("min", $("#input-dia").val());
    }else{
      var results = diasEntreFechas(moment($("#input-dia").val()), moment($("#input-dia").val()), 1);
      $("#fecha").val(results);
      $("#input-fin").val($("#input-dia").val());
      $("#input-fin").attr("min", $("#input-dia").val());
    }
  });
  $("#buscadorPersonas").keyup(function(){
    var Mes = [];
    for (var i = 1; i <= Month[$("#mes").val()]; i++) {
      Mes.push(parseInt(i));
    }
    var fechaReporIni = new Date($("#mes").val()+"-1-"+$("#anio").val()).toISOString().split('T')[0];
    var fechaReporFin = new Date($("#mes").val()+"-"+Month[$("#mes").val()]+"-"+$("#anio").val()).toISOString().split('T')[0];
    $("#fecha1").val(fechaReporIni);
    $("#fecha2").val(fechaReporFin);
    $("#nombre").val($("#buscadorPersonas").val());
    var nombre = $(this).val();
    if(nombre !=  ""){
      buscador(nombre, Mes, fechaReporIni, fechaReporFin);
    }else{
      ajaxUser(Mes, fechaReporIni, fechaReporFin);
    }
  });
  $('#mysubmit').click(function(){
    formulario($("#input-dia").val(), $("#input-fin").val());
  });
  $("#id_users").keyup(function(){
    var nombre = $(this).val();
    if(nombre !=  ""){
      $.ajax({
        type: "POST",
        url: "reporte/buscador/" + nombre,
        beforeSend: function(){
            setTimeout(function(){
            }, 1500);
            $(".spinner-border").css("display","block");
        },
        success: function(data){
            $(".spinner-border").css("display","none");
            $("#suggesstion-box").show();
            $("#suggesstion-box").html(data);
            $("#id_users").css("background","#FFF");
        }
      });
    }else{
      $("#suggesstion-box").show();
      $("#suggesstion-box").html("Debe ingresar un usuario.");
      $("#id_users").css("background","#FFF");
    }
  });
});

function formulario(fechaDia, fechaFin){
  $.ajax({
    type: $('#formularioaenviar').attr('method'), 
    url: "reporte/store/"+fechaDia+"/"+fechaFin,
    data: $('#formularioaenviar').serialize(), 
    success: function (data) { 
      if(data=="Ausencia ingresada con exito!! Redireccionando..."){
        mostrarMsj(data);
        setTimeout(function(){
          location.reload();
        },3000);
      }else{
        mostrarError(data);
      }   
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
      alert("Error al enviar el formulario");
    } 
  });
}

function mostrarMsj(msj){
  $(".toast-body").text(msj);
  $('.toast-placement-ex').removeClass("hide");
  $('.toast-placement-ex').addClass("m-2 bg-success bottom-0 end-0 fade show");
  setTimeout(function(){
    $('.toast-placement-ex').removeClass("m-2 bg-success bottom-0 end-0 fade show");
    $('.toast-placement-ex').addClass("hide");
  }, 5000);
}

function selectUser(val,ide) {
    $("#id_users").val(val);
    $("#asignar_user").html('<input type="hidden" name="id_user" id="id_user" value="'+ide+'">');
    $("#suggesstion-box").hide();
}

function mostrarError(msj){
  $(".toast-body").text(msj);
  $('.toast-placement-ex').removeClass("hide");
  $('.toast-placement-ex').addClass("m-2 bg-danger bottom-0 end-0 fade show");
  setTimeout(function(){
    $('.toast-placement-ex').removeClass("m-2 bg-danger bottom-0 end-0 fade show");
    $('.toast-placement-ex').addClass("hide");
  }, 5000);
}

function generarNav(Mes, id, result){
  var FirstDate_ = new Date().toISOString();
  var FirstDate__ = FirstDate_.replace("T", " ");
  var FirstDate = FirstDate__.substring(0 , 19);
  var FirstDay = FirstDate.split(" ");
  var FirstToday = FirstDay[0].split("-");
  var FirstMonth = new Date().getMonth();
  var mesF = FirstMonth+1;
  let Month = [0,31,28,31,30,31,30,31,31,30,31,30,31];
  var FirstYear = new Date().getFullYear();
  var fechaReporIni = new Date($("#mes").val()+"-1-"+$("#anio").val()).toISOString().split('T')[0];
  var fechaReporFin = new Date($("#mes").val()+"-"+Month[$("#mes").val()]+"-"+$("#anio").val()).toISOString().split('T')[0];
  const ul = document.querySelector("#id"+id);
  for (var i =0; i < Mes.length; i++) {
    let li = document.createElement("li");
    li.setAttribute("class", "page-item tol"+id+" avatar avatar-xs pull-up");
    let a = document.createElement("button");
    a.setAttribute("class", "page-link num"+Mes[i]+" text-nowrap");
    a.setAttribute("type", "button");
    a.setAttribute("data-bs-toggle", "tooltip");
    a.setAttribute("data-bs-offset", "0,4");
    a.setAttribute("data-bs-html", "true");
    a.setAttribute("data-bs-placement", "top");
    a.setAttribute("title", " ");
    let aText = document.createTextNode(Mes[i]);
    a.appendChild(aText);
    li.appendChild(a);
    ul.appendChild(li);
  }
  var usuarios = [];
  var dia_actual = moment(fechaReporIni);
  const feriados = ["2022-01-01","2022-04-15","2022-04-16","2022-05-01","2022-05-21","2022-06-21","2022-06-27","2022-07-16","2022-08-15","2022-09-16","2022-09-18","2022-09-19","2022-10-10","2022-10-31","2022-11-01","2022-12-08","2022-12-25"];
  var fechas = [];
  while (dia_actual.isSameOrBefore(moment(fechaReporFin))) {
    fechas.push(dia_actual.format('YYYY-MM-DD'));
    dia_actual.add(1, 'days');  
  }
  for (var j = 0; j < feriados.length; j++) {
    for (var i = 0; i < fechas.length; i++) {
      var diaS = new Date(fechas[i]).getUTCDay();
      var diaLV_ = new Date(fechas[i]).toISOString().split('T')[0];
      var diaLV = diaLV_.split("-");
      if(document.querySelector(".tol"+result[id].id+" .num"+parseInt(diaLV[2]))!=null){
        const mensaje = document.querySelector(".tol"+result[id].id+" .num"+parseInt(diaLV[2]));
        if(parseInt(diaS)==0){
          $(".id"+result[id].id+" .num"+parseInt(diaLV[2])).addClass("btn btn-danger text-white");
          mensaje.setAttribute("data-bs-original-title", "<i class='bx bxs-happy-alt'></i> Domingo");
          $(".id"+result[id].id+" .num"+parseInt(diaLV[2])).tooltip({html: true});
        }else if(parseInt(diaS)==6){
          $(".id"+result[id].id+" .num"+parseInt(diaLV[2])).addClass("btn btn-danger text-white");
          mensaje.setAttribute("data-bs-original-title", "<i class='bx bxs-happy-alt'></i> Sabado");
          $(".id"+result[id].id+" .num"+parseInt(diaLV[2])).tooltip({html: true});
        }else{
          if(feriados[j].toString()==fechas[i].toString()){
            const mensaje = document.querySelector(".tol"+result[id].id+" .num"+parseInt(diaLV[2]));
            $(".id"+result[id].id+" .num"+parseInt(diaLV[2])).addClass("btn btn-primary text-white");
            mensaje.setAttribute("title", "<i class='bx bxs-happy-heart-eyes'></i> Feriado");
            $(".id"+result[id].id+" .num"+parseInt(diaLV[2])).tooltip({html: true});
          }
        }
      }
    }
  }
  $.each(result[id].fechas, function(l,item){
    var ResultDay = result[id].fechas[l].fecha.split(" ");
    var diaB = ResultDay[0].split("-");
    if(parseInt(result[id].fechas[l].cantidad)==0){
      const mensaje = document.querySelector(".tol"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
      if(parseInt(result[id].fechas[l].id_tipo_permiso)==8 & parseInt(result[id].fechas[l].id_usuario)==id){
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
        mensaje.setAttribute("data-bs-original-title", "<i class='bx bxs-cool'></i> Feriado Legal");
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
      }else if(parseInt(result[id].fechas[l].id_tipo_permiso)==9 & parseInt(result[id].fechas[l].id_usuario)==id){
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
        mensaje.setAttribute("title", "Licencia Medica");
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
      }else if(parseInt(result[id].fechas[l].id_tipo_permiso)==6 & parseInt(result[id].fechas[l].id_usuario)==id){
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
        mensaje.setAttribute("title",result[id].fechas[l].permiso);
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
      }else if(parseInt(result[id].fechas[l].id_tipo_permiso)==7 & parseInt(result[id].fechas[l].id_usuario)==id){
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
        mensaje.setAttribute("data-bs-original-title", "<i class='bx bxs-happy-beaming'></i> Permiso 347");
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
      }else if(parseInt(result[id].fechas[l].id_tipo_permiso)==3 & parseInt(result[id].fechas[l].id_usuario)==id){
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-warning text-white tachar");
        mensaje.setAttribute("data-bs-original-title", "<i class='bx bxs-confused'></i> Turno");
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
      }else if(parseInt(result[id].fechas[l].id_tipo_permiso)==10 & parseInt(result[id].fechas[l].id_usuario)==id){
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-dark text-white");
        var nombre = result[id].username.split(" ");
        console.log(nombre[0]);
        mensaje.setAttribute("data-bs-original-title", "<i class='bx bxs-star' ></i> ¡Feliz Cumpleaños! "+nombre[0]);
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
      }
    }else if(parseInt(result[id].fechas[l].cantidad)!=0){
      if(usuarios[result[id].fechas[l].id_usuario]!=2){
        if(parseInt(result[id].fechas[l].id_tipo_registro)==1 & (parseInt(result[id].fechas[l].id_tipo_permiso)==1 | parseInt(result[id].fechas[l].id_tipo_permiso)==2) & parseInt(result[id].fechas[l].id_usuario)==id){
          const a__ = document.querySelector(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
          const classes = a__.classList;
          if (classes.contains("btn-success")) {
          }else{
            $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).removeClass("btn btn-info text-white");
            $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-success text-white");
            
          }
          const Entrada = document.querySelector(".tol"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
          if(Entrada.title.toString().indexOf("Salida: ") != -1){
            Entrada.setAttribute("title", "<i class='bx bxs-time' ></i> Entrada: "+ResultDay[1]+"/"+Entrada.title.toString());
            $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
          }else{
            Entrada.setAttribute("data-bs-original-title", "<i class='bx bxs-time' ></i> Entrada: "+ResultDay[1]);
            $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
          }
          usuarios[result[id].fechas[l].id_usuario] = 1;
        }
      }
      if(parseInt(result[id].fechas[l].id_tipo_registro)==1 & (parseInt(result[id].fechas[l].id_tipo_permiso)==1 | parseInt(result[id].fechas[l].id_tipo_permiso)==2) & parseInt(result[id].fechas[l].id_usuario)==id){
        const Entrada = document.querySelector(".tol"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
        if(Entrada.title.toString().indexOf("Salida: ") != -1){
          Entrada.setAttribute("title", "<i class='bx bxs-time' ></i> Entrada: "+ResultDay[1]+"/"+Entrada.title.toString());
          $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
        }else{
          Entrada.setAttribute("data-bs-original-title", "<i class='bx bxs-time' ></i> Entrada: "+ResultDay[1]);
          $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).tooltip({html: true});
        }
      }
      if(parseInt(result[id].fechas[l].id_tipo_registro)==2 & (parseInt(result[id].fechas[l].id_tipo_permiso)==1 | parseInt(result[id].fechas[l].id_tipo_permiso)==2) & parseInt(result[id].fechas[l].id_usuario)==id){
        const Salida = document.querySelector(".tol"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).removeClass("btn btn-success text-white tachar");
        $(".id"+result[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-info text-white tachar");
        Salida.setAttribute("title", "Salida: "+ResultDay[1]);
        usuarios[result[id].fechas[l].id_usuario] = 2;
      }
    }
  })
}

function usuario(Mes, result){
  const tbody = document.querySelector(".table-border-bottom-0");
  $(".table-border-bottom-0").empty();
  var a = 1;
  $.each(result, function(j,item){
    if(result[j].id_estado!=2){
      if((result[j].fechas).length!=0){
        let tr = document.createElement("tr");
        let idtd = document.createElement("td");
        let idtdText = document.createTextNode(a++);
        idtd.appendChild(idtdText);
        tr.appendChild(idtd);
        let nombretd = document.createElement("td");
        let nombrei = document.createElement("i");
        user_ = result[j].username.split(" ");
        let nombreiText = document.createTextNode(user_[0]);
        nombrei.appendChild(nombreiText);
        nombretd.appendChild(nombrei);
        tr.appendChild(nombretd);
        let diastd = document.createElement("td");
        let diasnav = document.createElement("nav");
        diasnav.setAttribute("aria-label", "Page navigation");
        let diasul = document.createElement("ul");
        diasul.setAttribute("class", "pagination justify-content-center id"+result[j].id);
        diasul.setAttribute("id", "id"+result[j].id);
        diasnav.appendChild(diasul);
        diastd.appendChild(diasnav);
        tr.appendChild(diastd);
        tbody.appendChild(tr);

        generarNav(Mes, result[j].id, result);
      }
    }
  });
}

function ajaxUser(Mes, fechaReporIni, fechaReporFin){
  $.ajax({
    url: "reporte/usuario/"+fechaReporIni+"/"+fechaReporFin,
    dataType: "json",
    type:"POST",
    success:function(resultdo){
      usuario(Mes, resultdo);
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
      $(".table-border-bottom-0").empty();
    }
  });
}

function buscador(nombre, Mes, fechaReporIni, fechaReporFin){
  $.ajax({
    type: "POST",
    dataType: "json",
    url: "reporte/buscadorPersonas/"+nombre+"/"+fechaReporIni+"/"+fechaReporFin,
    success: function(resultdo){
      usuario(Mes, resultdo);
    },
    error: function(XMLHttpRequest, textStatus, errorThrown) { 
      $(".table-border-bottom-0").empty();
    }
  });
}

function diasEntreFechas(desde, hasta, valor) {
  var dia_actual = desde;
  var fechas = [];
  const feriados = ["2022-01-01","2022-04-15","2022-04-16","2022-05-01","2022-05-21","2022-06-21","2022-06-27","2022-07-16","2022-08-15","2022-09-16","2022-09-18","2022-09-19","2022-10-10","2022-10-31","2022-11-01","2022-12-08","2022-12-25"];
  if(valor==0){
    while (dia_actual.isSameOrBefore(hasta)) {
      fechas.push(dia_actual.format('YYYY-MM-DD'));
      dia_actual.add(1, 'days');  
    }
    var otroArray = fechas;
  }else{
    while (dia_actual.isSameOrBefore(hasta)) {
      fechas.push(dia_actual.format('YYYY-MM-DD'));
      dia_actual.add(1, 'days');  
    }
    var otroArray = [];
    for (var i = 0; i < fechas.length; i++) {
      var dia = new Date(fechas[i]).getUTCDay();
      if(parseInt(dia)==0){
      }else if(parseInt(dia)==6){
      }else{
        otroArray.push(fechas[i].toString());
      }
    }
    var sinFeriados = [];
    for (var j = 0; j < feriados.length; j++) {
      for (var i = 0; i < otroArray.length; i++) {
        if(feriados[j].toString()==otroArray[i].toString()){
          otroArray.splice(i,1);
        }else{
        }
      }
    }
  }
  return otroArray;
}

function mostrar(id){
  var x = document.getElementById(id);
  if (x.style.display === "none") {
    x.style.display = "block";
  }
}

function ocultar(id){
  var x = document.getElementById(id);
  if (x.style.display === "block") {
    x.style.display = "none";
  }
}

