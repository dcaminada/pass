$( document ).ready(function() {

  let Month = [0,31,28,31,30,31,30,31,31,30,31,30,31]
  var Day = new Date().getUTCDay();
  var FirstMonth = new Date().getMonth();
  var FirstDate = new Date().toUTCString();
  var FirstDay = FirstDate.split(" ");
  var Week = [];
  if (Day==0) {
    Day = 7;
  }
  var limitSup = 7 - Day;
  var LimitInf = Day - 1;
  var negativo = 0;
  var positivo = 0;
  
  for (var i = LimitInf; i >= 1; i--) {
    if((parseInt(FirstDay[1])-i)>=1){
      Week.push(parseInt(FirstDay[1]) - i);
    }else{
      negativo++;
    }
  }
  Week.push(parseInt(FirstDay[1]));
  for (var i = 1; i <= limitSup; i++) {
    if((parseInt(FirstDay[1])+i)<=(Month[FirstMonth+1])){
      Week.push(parseInt(FirstDay[1]) + i);
    }else{
      positivo++;
    }
  }

  if((Week.length)<=7){
    var valor = 7 - Week.length;
    if(positivo>0){
      for (var j = 1; j <= valor; j++) {
          Week.push(j);
      }
    }else if(negativo>0){
      for (var k = (Month[FirstMonth]); k > ((Month[FirstMonth]) - valor); k--) {
          Week.unshift(k);
      }
    }
  }

  ajaxUser(Week);
  

  $("#permiso").on( 'change', function() {
    const checkboxDate = document.querySelector("#masDia");
    const inputDate = document.querySelector("#input-fin");
    if($("#permiso").val()==0){
        $("#mysubmit").addClass("disabled");
        ocultar("detalle");
        ocultar("divHidden");
        checkboxDate.setAttribute("disabled", "");
        inputDate.setAttribute("disabled", "");
        $("#ldia").text("Dia");
        $("#lfin").text(" - ");
    }else if($("#permiso").val()==2){
        ocultar("detalle");
        ocultar("divHidden");
        checkboxDate.removeAttribute("disabled");
        $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==3){
        ocultar("detalle");
        ocultar("divHidden");
        checkboxDate.removeAttribute("disabled");
        $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==4){
        mostrar("detalle");
        ocultar("divHidden");
        checkboxDate.removeAttribute("disabled");
        inputDate.setAttribute("disabled", "");
        $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==5){
        ocultar("detalle");
        ocultar("divHidden");
        checkboxDate.removeAttribute("disabled");
        $("#mysubmit").removeClass("disabled");
    }else if($("#permiso").val()==6){
        ocultar("detalle");
        mostrar("divHidden");
        inputDate.setAttribute("disabled", "");
        checkboxDate.setAttribute("disabled", "");
        $("#mysubmit").removeClass("disabled");
    }
  });

  const checkboxDate = document.querySelector("#masDia");
  checkboxDate.addEventListener( 'change', function() {
    if(this.checked) {
        const inputDate = document.querySelector("#input-fin");
        inputDate.removeAttribute("disabled");
        $("#ldia").text("Inicio");
        $("#lfin").text("Fin");
    } else {
        const inputDate = document.querySelector("#input-fin");
        inputDate.setAttribute("disabled", "");
        $("#ldia").text("Dia");
        $("#lfin").text(" - ");
    }
  });

  const checkboxManana = document.querySelector("#manana");
  checkboxManana.addEventListener( 'change', function() {
    if(this.checked) {
        const checkboxTarde = document.querySelector("#tarde");
        checkboxTarde.setAttribute("disabled", "");
    } else {
        const checkboxTarde = document.querySelector("#tarde");
        checkboxTarde.removeAttribute("disabled");
    }
  });

  const checkboxTarde = document.querySelector("#tarde");
  checkboxTarde.addEventListener( 'change', function() {
    if(this.checked) {
        const checkboxManana = document.querySelector("#manana");
        checkboxManana.setAttribute("disabled", "");
    } else {
        const checkboxManana = document.querySelector("#manana");
        checkboxManana.removeAttribute("disabled");
    }
  });

  
  const finDate = document.querySelector("#input-fin");
  finDate.addEventListener( 'change', function() {
    var results = diasEntreFechas(moment($("#input-dia").val()), moment($("#input-fin").val()));
    $("#fecha").val(results);
  });

  const diaDate = document.querySelector("#input-dia");
  diaDate.addEventListener( 'change', function() {
    var results = diasEntreFechas(moment($("#input-dia").val()), moment($("#input-dia").val()));
    $("#fecha").val(results);
    $("#input-fin").val($("#input-dia").val());
    $("#input-fin").attr("min", $("#input-dia").val());
  });



  $("#buscadorPersonas").keyup(function(){
        var nombre = $(this).val();
        if(nombre !=  ""){
            $.ajax({
            type: "POST",
            dataType: "json",
            url: "home/buscadorPersonas/" + nombre,
            success: function(resultado){
                usuarioB(Week, resultado);
            }
            });
        }else{
          ajaxUser(Week);
        }
  });


  $('#mysubmit').click(function(){
      $.ajax({
        type: $('#formularioaenviar').attr('method'), 
        url: "home/store/"+$("#input-dia").val()+"/"+$("#input-fin").val(),
        data: $('#formularioaenviar').serialize(), 
        success: function (data) { 
          if(data=="Ausencia ingresada con exito!! Redireccionando..."){
            mostrarMsj_(data);
            setTimeout(function(){
                location.reload();
            },3000);
          }else{
            mostrarMsj(data);
          }
            
        } 
      });
  });

});


function mostrarMsj_(msj){
  $(".toast-body").text(msj);
  $('.toast-placement-ex').removeClass("hide");
  $('.toast-placement-ex').addClass("m-2 bg-success bottom-0 end-0 fade show");
  setTimeout(function(){
      $('.toast-placement-ex').removeClass("m-2 bg-success bottom-0 end-0 fade show");
      $('.toast-placement-ex').addClass("hide");
  }, 5000);
}

function mostrarMsj(msj){
  $(".toast-body").text(msj);
  $('.toast-placement-ex').removeClass("hide");
  $('.toast-placement-ex').addClass("m-2 bg-danger bottom-0 end-0 fade show");
  setTimeout(function(){
      $('.toast-placement-ex').removeClass("m-2 bg-danger bottom-0 end-0 fade show");
      $('.toast-placement-ex').addClass("hide");
  }, 5000);
}



function generarNavB(Week, id, result){
  var FirstDate_ = new Date().toISOString();
  var FirstDate__ = FirstDate_.replace("T", " ");
  var FirstDate = FirstDate__.substring(0 , 19);
  var FirstDay = FirstDate.split(" ");
  var FirstToday = FirstDay[0].split("-");
  var FirstMonth = new Date().getMonth();
  var mesF = FirstMonth+1;
  const ul = document.querySelector("#id"+id);
  for (var i =0; i < Week.length; i++) {
      let li = document.createElement("li");
      li.setAttribute("class", "page-item tol"+id+" avatar avatar-xs pull-up");
      let a = document.createElement("button");
      a.setAttribute("class", "page-link num"+Week[i]+" text-nowrap");
      a.setAttribute("type", "button");
      a.setAttribute("data-bs-toggle", "tooltip");
      a.setAttribute("data-bs-offset", "0,4");
      a.setAttribute("data-bs-html", "true");
      a.setAttribute("data-bs-placement", "top");
      a.setAttribute("title", " ");
      let aText = document.createTextNode(Week[i]);
      a.appendChild(aText);
      li.appendChild(a);
      ul.appendChild(li);
  }
  var resulta = result[0];
  var usuarios = [];
  $.each(resulta, function(j,item){
    $.each(result[1], function(l,item){
      var ResultDay = result[1][l].fecha.split(" ");
      var diaB = ResultDay[0].split("-");
      if ((FirstDay[0]).toString()==(ResultDay[0]).toString() & parseInt(resulta[j].cantidad)==1 & parseInt(resulta[j].id)==id) {
          $(".badge"+resulta[j].id).text("Disponible");
          $(".badge"+resulta[j].id).addClass("bg-label-success");
          $(".badge"+resulta[j].id).removeClass("bg-label-secondary");
      }
      for (var k =0; k < Week.length; k++) {
          const mensaje = document.querySelector(".tol"+result[1][l].id_usuario+" .num"+Week[k]);
          if(parseInt(result[1][l].id_tipo_permiso)==2 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-secondary text-white tachar");
            mensaje.setAttribute("title", "Feriado Legal");
          }else if(parseInt(result[1][l].id_tipo_permiso)==3 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-secondary text-white tachar");
            mensaje.setAttribute("title", "Licencia Medica");
          }else if(parseInt(result[1][l].id_tipo_permiso)==4 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-secondary text-white tachar");
            mensaje.setAttribute("title",result[1][l].permiso);
          }else if(parseInt(result[1][l].id_tipo_permiso)==5 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-secondary text-white tachar");
            mensaje.setAttribute("title", "Permiso 347");
          }else if(parseInt(result[1][l].id_tipo_permiso)==6 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-secondary text-white tachar");
            mensaje.setAttribute("title", "Media Jornada");
          }
          if(usuarios[result[1][l].id_usuario]!=2){
              if(parseInt(result[1][l].id_tipo_registro)==1 & parseInt(result[1][l].id_tipo_permiso)==1 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
                const a__ = document.querySelector(".id"+result[1][l].id_usuario+" .num"+Week[k]);
                const classes = a__.classList;
                if (classes.contains("btn-success")) {
                }else{
                  $(".id"+result[1][l].id_usuario+" .num"+Week[k]).removeClass("btn btn-info text-white");
                  $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-success text-white");
                }
                const Entrada = document.querySelector(".tol"+result[1][l].id_usuario+" .num"+Week[k]);
                if(Entrada.title.toString().indexOf("Salida: ") != -1){
                  Entrada.setAttribute("title", "Entrada: "+ResultDay[1]+"/"+Entrada.title.toString());
                }else{
                  Entrada.setAttribute("title", "Entrada: "+ResultDay[1]);
                }
                usuarios[result[1][l].id_usuario] = 1;
              }
          }
          if(parseInt(result[1][l].id_tipo_registro)==1 & parseInt(result[1][l].id_tipo_permiso)==1 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            const Entrada = document.querySelector(".tol"+result[1][l].id_usuario+" .num"+Week[k]);
            if(Entrada.title.toString().indexOf("Salida: ") != -1){
              Entrada.setAttribute("title", "Entrada: "+ResultDay[1]+"/"+Entrada.title.toString());
            }else{
              Entrada.setAttribute("title", "Entrada: "+ResultDay[1]);
            }
          }
          if(parseInt(result[1][l].id_tipo_registro)==2 & parseInt(result[1][l].id_tipo_permiso)==1 & parseInt(result[1][l].id_usuario)==id & parseInt(diaB[2])==parseInt(Week[k])){
            const Salida = document.querySelector(".tol"+result[1][l].id_usuario+" .num"+Week[k]);
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).removeClass("btn btn-success text-white tachar");
            $(".id"+result[1][l].id_usuario+" .num"+Week[k]).addClass("btn btn-info text-white tachar");
            Salida.setAttribute("title", "Salida: "+ResultDay[1]);
            usuarios[result[1][l].id_usuario] = 2;
          }
      }
    })
  })

}

function usuarioB(Week, result){
    const tbody = document.querySelector(".table-border-bottom-0");
    $(".table-border-bottom-0").empty();
    $.each(result[0], function(j,item){
          let tr = document.createElement("tr");
          let idtd = document.createElement("td");
          let idtdText = document.createTextNode(result[0][j].id);
          idtd.appendChild(idtdText);
          tr.appendChild(idtd);
          let nombretd = document.createElement("td");
          let nombrei = document.createElement("i");
          let nombreiText = document.createTextNode(result[0][j].username);
          nombrei.appendChild(nombreiText);
          nombretd.appendChild(nombrei);
          tr.appendChild(nombretd);
          nombrei.setAttribute("class", "fab fa-angular fa-lg me-3");
          let estadotd = document.createElement("td");
          let estadospan = document.createElement("span");
          estadospan.setAttribute("class", "badge bg-label-secondary me-1 badge"+result[0][j].id);
          let estadospanText = document.createTextNode("Ausente");
          estadospan.appendChild(estadospanText);
          estadotd.appendChild(estadospan);
          tr.appendChild(estadotd);
          let diastd = document.createElement("td");
          let diasnav = document.createElement("nav");
          diasnav.setAttribute("aria-label", "Page navigation");
          let diasul = document.createElement("ul");
          diasul.setAttribute("class", "pagination justify-content-center id"+result[0][j].id);
          diasul.setAttribute("id", "id"+result[0][j].id);
          diasnav.appendChild(diasul);
          diastd.appendChild(diasnav);
          tr.appendChild(diastd);
          let accionestd = document.createElement("td");
          let accionesdiv = document.createElement("div");
          accionesdiv.setAttribute("class", "dropdown");
          if($("#casualidad").val()==result[0][j].id){
            let accionesbutton = document.createElement("a");
            accionesbutton.setAttribute("class", "btn p-0 hide-arrow");
            accionesbutton.setAttribute("type", "button");
            accionesbutton.setAttribute("href", "javascript:void(0);");
            let accionesi = document.createElement("i");
            accionesi.setAttribute("class", "bx bx-search-alt-2");
            accionesbutton.appendChild(accionesi);
            accionesdiv.appendChild(accionesbutton);
          }
          accionestd.appendChild(accionesdiv);
          tr.appendChild(accionestd);
          tbody.appendChild(tr);
          generarNavB(Week, result[0][j].id, result);
      });

}

function generarNav(Week, id_, result){
  var FirstDate_ = new Date().toISOString();
  var FirstDate__ = FirstDate_.replace("T", " ");
  var FirstDate = FirstDate__.substring(0 , 19);
  var FirstDay = FirstDate.split(" ");
  var FirstToday = FirstDay[0].split("-");
  var FirstMonth = new Date().getMonth();
  var mesF = FirstMonth+1;
  const ul = document.querySelector("#id"+id_);
  for (var i =0; i < Week.length; i++) {
      let li = document.createElement("li");
      li.setAttribute("class", "page-item tol"+id_+" avatar avatar-xs pull-up");
      let a = document.createElement("button");
      a.setAttribute("class", "page-link num"+Week[i]+" text-nowrap");
      a.setAttribute("type", "button");
      a.setAttribute("data-bs-toggle", "tooltip");
      a.setAttribute("data-bs-offset", "0,4");
      a.setAttribute("data-bs-html", "true");
      a.setAttribute("data-bs-placement", "top");
      a.setAttribute("title", " ");
      let aText = document.createTextNode(Week[i]);
      a.appendChild(aText);
      li.appendChild(a);
      ul.appendChild(li);
  }
  var resulta = result[0];
  var id = id_ - 1;
  var usuarios = [];
  $.each(resulta[id].fechas, function(l,item){
    var ResultDay = resulta[id].fechas[l].fecha.split(" ");
    var diaB = ResultDay[0].split("-");
    if ((FirstDay[0]).toString()==(ResultDay[0]).toString() & parseInt(resulta[id].cantidad)==1 & parseInt(resulta[id].fechas[l].id_usuario)==id_) {
        $(".badge"+id_).text("Disponible");
        $(".badge"+id_).addClass("bg-label-success");
        $(".badge"+id_).removeClass("bg-label-secondary");
    }
    const mensaje = document.querySelector(".tol"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
    if(parseInt(resulta[id].fechas[l].id_tipo_permiso)==2 & parseInt(resulta[id].fechas[l].id_usuario)==id){
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
      mensaje.setAttribute("title", "Feriado Legal");
    }else if(parseInt(resulta[id].fechas[l].id_tipo_permiso)==3 & parseInt(resulta[id].fechas[l].id_usuario)==id){
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
      mensaje.setAttribute("title", "Licencia Medica");
    }else if(parseInt(resulta[id].fechas[l].id_tipo_permiso)==4 & parseInt(resulta[id].fechas[l].id_usuario)==id){
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
      mensaje.setAttribute("title",resulta[id].fechas[l].permiso);
    }else if(parseInt(resulta[id].fechas[l].id_tipo_permiso)==5 & parseInt(resulta[id].fechas[l].id_usuario)==id){
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
      mensaje.setAttribute("title", "Permiso 347");
    }else if(parseInt(resulta[id].fechas[l].id_tipo_permiso)==6 & parseInt(resulta[id].fechas[l].id_usuario)==id){
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-secondary text-white tachar");
      mensaje.setAttribute("title", "Media Jornada");
    }
    if(usuarios[resulta[id].fechas[l].id_usuario]!=2){
        if(parseInt(resulta[id].fechas[l].id_tipo_registro)==1 & parseInt(resulta[id].fechas[l].id_tipo_permiso)==1 & parseInt(resulta[id].fechas[l].id_usuario)==id_){
          const a__ = document.querySelector(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
          const classes = a__.classList;
          if (classes.contains("btn-success")) {
          }else{
            $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).removeClass("btn btn-info text-white");
            $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-success text-white");
            
          }
          const Entrada = document.querySelector(".tol"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
          if(Entrada.title.toString().indexOf("Salida: ") != -1){
            Entrada.setAttribute("title", "Entrada: "+ResultDay[1]+"/"+Entrada.title.toString());
          }else{
            Entrada.setAttribute("title", "Entrada: "+ResultDay[1]);
          }
          usuarios[resulta[id].fechas[l].id_usuario] = 1;
        }
    }
    if(parseInt(resulta[id].fechas[l].id_tipo_registro)==1 & parseInt(resulta[id].fechas[l].id_tipo_permiso)==1 & parseInt(resulta[id].fechas[l].id_usuario)==id_){
      const Entrada = document.querySelector(".tol"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
      if(Entrada.title.toString().indexOf("Salida: ") != -1){
        Entrada.setAttribute("title", "Entrada: "+ResultDay[1]+"/"+Entrada.title.toString());
      }else{
        Entrada.setAttribute("title", "Entrada: "+ResultDay[1]);
      }
    }
    if(parseInt(resulta[id].fechas[l].id_tipo_registro)==2 & parseInt(resulta[id].fechas[l].id_tipo_permiso)==1 & parseInt(resulta[id].fechas[l].id_usuario)==id_){
      const Salida = document.querySelector(".tol"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2]));
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).removeClass("btn btn-success text-white tachar");
      $(".id"+resulta[id].fechas[l].id_usuario+" .num"+parseInt(diaB[2])).addClass("btn btn-info text-white tachar");
      Salida.setAttribute("title", "Salida: "+ResultDay[1]);
      usuarios[resulta[id].fechas[l].id_usuario] = 2;
    }

  })

}

function usuario(Week, result){
    const tbody = document.querySelector(".table-border-bottom-0");
    $(".table-border-bottom-0").empty();
    $.each(result[0], function(j,item){
      if(result[0][j].id_estado!=2){
          let tr = document.createElement("tr");
          let idtd = document.createElement("td");
          let idtdText = document.createTextNode(result[0][j].id);
          idtd.appendChild(idtdText);
          tr.appendChild(idtd);
          let nombretd = document.createElement("td");
          let nombrei = document.createElement("i");
          let nombreiText = document.createTextNode(result[0][j].username);
          nombrei.appendChild(nombreiText);
          nombretd.appendChild(nombrei);
          tr.appendChild(nombretd);
          nombrei.setAttribute("class", "fab fa-angular fa-lg me-3");
          let estadotd = document.createElement("td");
          let estadospan = document.createElement("span");
          estadospan.setAttribute("class", "badge bg-label-secondary me-1 badge"+result[0][j].id);
          let estadospanText = document.createTextNode("Ausente");
          estadospan.appendChild(estadospanText);
          estadotd.appendChild(estadospan);
          tr.appendChild(estadotd);
          let diastd = document.createElement("td");
          let diasnav = document.createElement("nav");
          diasnav.setAttribute("aria-label", "Page navigation");
          let diasul = document.createElement("ul");
          diasul.setAttribute("class", "pagination justify-content-center id"+result[0][j].id);
          diasul.setAttribute("id", "id"+result[0][j].id);
          diasnav.appendChild(diasul);
          diastd.appendChild(diasnav);
          tr.appendChild(diastd);
          let accionestd = document.createElement("td");
          let accionesdiv = document.createElement("div");
          accionesdiv.setAttribute("class", "dropdown");
          if($("#casualidad").val()==result[0][j].id){
            let accionesbutton = document.createElement("a");
            accionesbutton.setAttribute("class", "btn p-0 hide-arrow");
            accionesbutton.setAttribute("type", "button");
            accionesbutton.setAttribute("href", "javascript:void(0);");
            let accionesi = document.createElement("i");
            accionesi.setAttribute("class", "bx bx-search-alt-2");
            accionesbutton.appendChild(accionesi);
            accionesdiv.appendChild(accionesbutton);
          }
          accionestd.appendChild(accionesdiv);
          tr.appendChild(accionestd);
          tbody.appendChild(tr);
          generarNav(Week, result[0][j].id, result);
      }
    });

}

function ajaxUser(Week){
    $.ajax({
      url: "home/usuario",
      dataType: "json",
      type:"POST",
      success:function(resultado){
          usuario(Week, resultado);
      }
    });
}


function diasEntreFechas(desde, hasta) {
    var dia_actual = desde;
    var fechas = [];
    const feriados = ["2022-04-15","2022-05-01","2022-06-06"];
    while (dia_actual.isSameOrBefore(hasta)) {
        fechas.push(dia_actual.format('YYYY-MM-DD'));
        dia_actual.add(1, 'days');  
    }
    var otroArray = [];
    for (var i = 0; i < fechas.length; i++) {
      var dia = new Date(fechas[i]).getUTCDay();
      if(parseInt(dia)==0){
      }else if(parseInt(dia)==6){
      }else{
          otroArray.push(fechas[i].toString());
      }
    }
    var sinFeriados = [];
    for (var j = 0; j < feriados.length; j++) {
      for (var i = 0; i < otroArray.length; i++) {
        if(feriados[j].toString()==otroArray[i].toString()){
            otroArray.splice(i,1);
        }else{
        }
      }
    }
    return otroArray;
}


function mostrar(id){
    var x = document.getElementById(id);
    if (x.style.display === "none") {
        x.style.display = "block";
    }
}

function ocultar(id){
  var x = document.getElementById(id);
  if (x.style.display === "block") {
      x.style.display = "none";
  }
}
