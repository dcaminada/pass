$(document).ready(function() {
            $("#generar").click(function() {
                let nombreCompleto = $("#nombre").val();
                let palabras = nombreCompleto.split(" ");
                let palabraMasLarga = palabras.reduce((a, b) => a.length > b.length ? a : b);

                let nombreTransformado = palabraMasLarga.replace(/a/g, '4')
                                                        .replace(/e/g, '3')
                                                        .replace(/i/g, '1')
                                                        .replace(/o/g, '0')
                                                        .replace(/u/g, 'u');

                let reg = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{12,}$/;

                // Genera una contraseña que cumpla con la expresión regular
                let pass = generarpassValida(nombreTransformado, reg);

                if (reg.test(pass)) {
                    $("#resultado").text(`Contraseña válida: ${pass}`);
                } else {
                    $("#resultado").text("No se pudo generar una contraseña válida.");
                }
            });

            function generarpassValida(base, regex) {
                let pass = base;
                const caracteresEspeciales = ".@#$%";
                const numeros = "0123456789";

                // Asegurar al menos una letra mayúscula si no existe
                if (!/[A-Z]/.test(pass)) {
                    pass += "A";
                }

                // Asegurar al menos un número si no existe
                if (!/[0-9]/.test(pass)) {
                    pass += "1";
                }

                // Asegurar al menos un carácter especial si no existe
                if (!/[^A-Za-z0-9]/.test(pass)) {
                    pass += caracteresEspeciales[Math.floor(Math.random() * caracteresEspeciales.length)];
                }

                // Remover caracteres especiales adicionales si existen
                pass = pass.replace(/[^A-Za-z0-9]/g, '');

                // Asegurar que solo haya un carácter especial
                pass += caracteresEspeciales[Math.floor(Math.random() * caracteresEspeciales.length)];

                // Completar la contraseña hasta alcanzar al menos 12 caracteres con números
                while (pass.length < 12) {
                    pass += numeros[Math.floor(Math.random() * numeros.length)];
                }

                // Si la longitud de la base ya es mayor que 12, recortar para asegurar que cumpla con la longitud
                if (pass.length > 12) {
                    pass = pass.substring(0, 12);
                }

                return pass;
            }
        });
